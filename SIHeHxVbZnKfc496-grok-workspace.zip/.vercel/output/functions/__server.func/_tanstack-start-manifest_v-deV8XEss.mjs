//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-deV8XEss.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BoCNytOC.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BoCNytOC.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-T0plkfto.js"]
	}
} });
//#endregion
export { tsrStartManifest };
