import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-AQXWqSya.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
		title: "Avangard Plus",
		src: "/avangard/index.html",
		style: {
			position: "fixed",
			inset: 0,
			width: "100%",
			height: "100%",
			border: 0,
			background: "#070712"
		}
	});
}
//#endregion
export { Home as component };
