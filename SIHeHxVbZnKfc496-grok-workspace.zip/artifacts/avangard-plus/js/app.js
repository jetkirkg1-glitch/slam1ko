const KEYS = {
  cart: "avp2_cart",
  products: "avp4_products",
  users: "avp2_users",
  session: "avp2_session",
  orders: "avp2_orders",
  slides: "avp3_slides",
  categories: "avp4_categories",
  zones: "avp5_zones"
};

const DELIVERY = {
  osh: { label: "Курьер по Ошу", price: 0 },
  pickup: { label: "Самовывоз: Курманжан Датка 469", price: 0 }
};

const STATUS = {
  pending: "Ожидает оплаты",
  paid: "Оплачен",
  packing: "Собирается",
  shipped: "В доставке",
  done: "Выполнен",
  cancelled: "Отменён",
  cod: "Оплата при получении",
  installment: "Рассрочка",
  waiting: "Ожидает подтверждения",
  confirmed: "Подтверждён"
};

const state = {
  category: "all",
  sort: "popular",
  query: "",
  cart: [],
  products: [],
  users: [],
  orders: [],
  session: null,
  currentProduct: null,
  editingProductId: null,
  pendingOrder: null,
  adminTab: "products",
  slides: [],
  installmentMode: false,
  categories: [],
  galleryIndex: 0,
  checkoutMode: "cash",
  page: "home",
  history: [],
  zones: []
};

function qs(sel, root = document) {
  return root.querySelector(sel);
}
function qsa(sel, root = document) {
  return [...root.querySelectorAll(sel)];
}
function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}
function save(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}
function formatPrice(n) {
  return new Intl.NumberFormat("ru-RU").format(Number(n) || 0) + " сом";
}
function uid(prefix) {
  return prefix + "-" + Math.floor(100000 + Math.random() * 900000);
}
function now() {
  return new Date().toLocaleString("ru-KG", {
    timeZone: "Asia/Bishkek",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }) + " · Ош";
}
function productImages(p) {
  if (!p) return [];
  if (Array.isArray(p.images) && p.images.length) return p.images.filter(Boolean);
  return p.image ? [p.image] : [];
}
function isHousehold(p) {
  return p && p.category !== "phones" && p.category !== "laptops" && p.category !== "printers";
}
function installCartTotal() {
  return state.cart.reduce((s, i) => {
    const prod = state.products.find((x) => x.id === i.id);
    if (!isHousehold(prod)) return s;
    return s + prod.price * i.qty;
  }, 0);
}
function canOfferInstall() {
  return installCartTotal() >= 10000;
}
function getCategories() {
  return state.categories.length ? state.categories : CATEGORIES;
}
function normTxt(s) {
  return String(s || "").toLowerCase().replace(/ё/g, "е").replace(/\s+/g, " ").trim();
}
function fuzzyHas(hay, q) {
  hay = normTxt(hay); q = normTxt(q);
  if (!q) return true;
  if (hay.includes(q)) return true;
  if (q.length < 3) return hay.startsWith(q) || hay.split(" ").some((w) => w.startsWith(q));
  let i = 0;
  for (const ch of hay) if (ch === q[i]) i++;
  if (i / q.length >= 0.75) return true;
  // one typo
  if (Math.abs(hay.length - q.length) <= 1 && q.length >= 3) {
    const a = hay.slice(0, 24), b = q.slice(0, 24);
    let d = 0, x = 0, y = 0;
    while (x < a.length && y < b.length) {
      if (a[x] === b[y]) { x++; y++; continue; }
      d++;
      if (d > 1) return false;
      if (a.length > b.length) x++;
      else if (b.length > a.length) y++;
      else { x++; y++; }
    }
    return true;
  }
  return false;
}
function isPhone(p) { return p && p.category === "phones"; }
function cashBonusBase() {
  return state.cart.reduce((s, i) => {
    const prod = state.products.find((x) => x.id === i.id);
    if (!prod || isPhone(prod)) return s;
    return s + prod.price * i.qty;
  }, 0);
}

function initStore() {
  state.products = load(KEYS.products, null);
  if (!Array.isArray(state.products) || state.products.length < 80) {
    state.products = structuredClone(PRODUCTS);
    save(KEYS.products, state.products);
  }
  state.users = load(KEYS.users, []);
  if (!state.users.length) {
    state.users = [
      {
        id: "u-admin",
        name: "Администратор",
        email: "admin@avangard-plus.ru",
        phone: "+996 557 767 636",
        password: "admin123",
        role: "admin",
        address: "Ош, Курманжан Датка 469",
        bonus: 1000,
        createdAt: now()
      }
    ];
    save(KEYS.users, state.users);
  }
  state.users.forEach((u) => {
    if (typeof u.bonus !== "number") u.bonus = 1000;
  });
  persistUsers();
  state.orders = load(KEYS.orders, []);
  state.cart = load(KEYS.cart, []);
  state.session = load(KEYS.session, null);
  const savedSlides = load(KEYS.slides, null);
  state.slides = Array.isArray(savedSlides) && savedSlides.length ? savedSlides : (typeof SLIDES !== "undefined" ? [...SLIDES] : [1, 13, 25]);
  const savedCats = load(KEYS.categories, null);
  state.categories = Array.isArray(savedCats) && savedCats.length ? savedCats : structuredClone(CATEGORIES);
  const savedZones = load(KEYS.zones, null);
  state.zones = Array.isArray(savedZones) && savedZones.length ? savedZones : DEFAULT_ZONES.map((z) => ({ ...z }));
}

function currentUser() {
  if (!state.session) return null;
  return state.users.find((u) => u.email === state.session.email) || null;
}
function isAdmin() {
  return currentUser()?.role === "admin";
}

function persistProducts() {
  save(KEYS.products, state.products);
}
function persistUsers() {
  save(KEYS.users, state.users);
}
function persistOrders() {
  save(KEYS.orders, state.orders);
}
function persistCart() {
  save(KEYS.cart, state.cart);
  renderCart();
}

function navigate(page, fromBack) {
  if (!fromBack && state.page && state.page !== page) {
    state.history.push(state.page);
    if (state.history.length > 20) state.history.shift();
  }
  if ((page === "cabinet" || page === "admin" || page === "waiting") && !currentUser()) {
    toast("Сначала войдите в аккаунт");
    page = "auth";
  }
  if (page === "admin" && !isAdmin()) {
    toast("Раздел только для администратора");
    page = "cabinet";
  }
  qsa(".page").forEach((p) => p.classList.remove("active"));
  const el = qs("#page-" + page);
  if (el) el.classList.add("active");
  qsa(".nav a[data-page]").forEach((a) => a.classList.toggle("active", a.dataset.page === page));
  qs(".nav")?.classList.remove("open");
  state.installmentMode = page === "installment";
  window.scrollTo({ top: 0, behavior: "smooth" });
  if (page === "catalog") renderCatalog();
  if (page === "installment") renderInstallment();
  if (page === "home") {
    renderHomeProducts();
    renderHomeCats();
    renderSlider();
  }
  if (page === "cabinet") renderCabinet();
  if (page === "waiting") renderWaiting();
  if (page === "admin") renderAdmin();
  if (page === "auth") switchAuthTab("login");
  state.page = page;
  qs("#burger-menu")?.classList.remove("open");
  document.body.dataset.page = page;
}

function openCategory(id) {
  state.category = id || "all";
  state.query = "";
  const search = qs("#search");
  if (search) search.value = "";
  navigate("catalog");
}

function renderSuggest(q) {
  const box = qs("#suggest");
  if (!box) return;
  q = String(q || "").trim();
  const hints = [];
  getCategories().forEach((c) => {
    if (c.id === "all") return;
    if (!q || fuzzyHas(c.label, q) || normTxt(c.label).startsWith(normTxt(q))) {
      hints.push({ type: "cat", id: c.id, label: c.label });
    }
  });
  state.products.forEach((p) => {
    if (q && (fuzzyHas(p.name, q) || normTxt(p.name).includes(normTxt(q)))) {
      hints.push({ type: "prod", id: p.id, label: p.name });
    }
  });
  const uniq = [];
  const seen = new Set();
  for (const h of hints) {
    const k = h.type + h.label;
    if (seen.has(k)) continue;
    seen.add(k);
    uniq.push(h);
    if (uniq.length >= 8) break;
  }
  if (!uniq.length) { box.classList.remove("open"); box.innerHTML = ""; return; }
  box.innerHTML = uniq.map((h) => `<button type="button" data-sug-type="${h.type}" data-sug-id="${h.id}">${h.label}</button>`).join("");
  box.classList.add("open");
}

function filteredProducts() {
  let list = state.products.filter((p) => {
    const byCat = state.category === "all" || p.category === state.category;
    const q = state.query.trim();
    const byQ = !q || fuzzyHas(p.name, q) || fuzzyHas(p.desc, q) || fuzzyHas(p.categoryLabel, q) || fuzzyHas(p.specs, q);
    return byCat && byQ;
  });
  if (state.sort === "price-asc") list.sort((a, b) => a.price - b.price);
  if (state.sort === "price-desc") list.sort((a, b) => b.price - a.price);
  if (state.sort === "rating") list.sort((a, b) => (b.rating || 0) - (a.rating || 0));
  if (state.sort === "popular") list.sort((a, b) => (b.reviews || 0) - (a.reviews || 0));
  return list;
}

function stars(r) {
  const n = Math.round(Number(r) || 0);
  return "★".repeat(Math.min(5, n)) + "☆".repeat(Math.max(0, 5 - n)) + ` ${r}`;
}

function planInstall(cash) {
  cash = Number(cash) || 0;
  const total = Math.round(cash * 1.15);
  if (cash <= 100000) {
    const monthly = Math.round(total / 6);
    return {
      cash, total, added: total - cash, rate: 15,
      down: monthly, monthsAfter: 5, monthly, scheme: "upto100"
    };
  }
  const down = Math.round(total * 0.3);
  const rest = total - down;
  const monthly = Math.round(rest / 5);
  return {
    cash, total, added: total - cash, rate: 15,
    down, monthsAfter: 5, monthly, scheme: "over100"
  };
}

const CAT_ICON = {
  washers: "🧺",
  semi: "🌀",
  fridges: "❄️",
  freezers: "🧊",
  ac: "💨",
  ovens: "🔥",
  microwave: "📡",
  hobs: "🍳",
  hoods: "🌬️",
  heaters: "🚿",
  vacuums: "🧹",
  stoves: "♨️",
  dishwashers: "🍽️",
  tvs: "📺",
  laptops: "💻",
  phones: "📱",
  printers: "🖨️",
  irons: "👔",
  kettles: "🫖",
  grinders: "🥩",
  juicers: "🍊",
  blenders: "🥤"
};

function persistSlides() {
  save(KEYS.slides, state.slides);
}
function persistCategories() {
  save(KEYS.categories, state.categories);
}

const DEFAULT_ZONES = [
  { id: "nookat", name: "Ноокат центр", price: 2500 },
  { id: "uzgen", name: "Озгон центр", price: 2500 },
  { id: "otuz", name: "Отуз Адыр", price: 1800 },
  { id: "kurshab", name: "Куршаб", price: 2000 },
  { id: "aravan", name: "Араван центр", price: 1500 },
  { id: "karatay", name: "Каратай", price: 1300 },
  { id: "karasuu", name: "Кара-Суу", price: 1000 },
  { id: "bash", name: "Баш булак", price: 1000 },
  { id: "mady", name: "Мады", price: 700 },
  { id: "kashkar", name: "Кашкар Кыштак", price: 500 },
  { id: "kenjekul", name: "Кенжекул Айыл", price: 500 },
  { id: "furkat", name: "Фуркат", price: 500 },
  { id: "kyrgyzchek", name: "Кыргыз чек", price: 600 },
  { id: "ozgur", name: "Озгур центр", price: 500 },
  { id: "mamakeev", name: "Мамакеев Центр", price: 500 }
];
function persistZones() { save(KEYS.zones, state.zones); }

function fileToJpeg(file, max) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("read"));
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, (max || 1100) / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.72));
      };
      img.onerror = () => reject(new Error("img"));
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}


function productCard(p) {
  const showInst = state.installmentMode && isHousehold(p) && p.price >= 10000;
  const plan = planInstall(p.price);
  const imgs = productImages(p);
  const priceBlock = showInst
    ? `<div class="price-row"><span class="price">${formatPrice(plan.down)}</span><span class="muted">первый месяц</span></div>
       <div class="muted">ещё ${plan.monthsAfter} × ${formatPrice(plan.monthly)} · всего ${formatPrice(plan.total)}</div>`
    : `<div class="price-row">
          <span class="price">${formatPrice(p.price)}</span>
          ${p.oldPrice ? `<span class="old">${formatPrice(p.oldPrice)}</span>` : ""}
        </div>
        ${!isHousehold(p) ? `<div class="muted">Только наличными · без рассрочки</div>` : ""}`;
  return `
    <article class="card" data-id="${p.id}">
      <div class="card-media">
        ${p.badge ? `<span class="tag">${p.badge}</span>` : ""}
        ${showInst ? `<span class="tag tag-inst">Рассрочка</span>` : ""}
        <img class="card-photo" src="${(imgs[0] || p.image)}" alt="${p.name}" loading="lazy">
        ${imgs.length > 1 ? `<button type="button" class="gal-nav prev" data-card-gal="-1" aria-label="Назад">‹</button><button type="button" class="gal-nav next" data-card-gal="1" aria-label="Дальше">›</button><span class="gal-count">1/${Math.min(4, imgs.length)}</span>` : ""}
      </div>
      <div class="card-body">
        <div class="cat">${p.categoryLabel || ""}</div>
        <h3>${p.name}</h3>
        <div class="stars">${stars(p.rating)} · ${p.reviews || 0}</div>
        ${priceBlock}
        <div class="card-actions">
          <button class="btn btn-blue btn-full" data-action="add" ${p.stock < 1 ? "disabled" : ""}>${p.stock < 1 ? "Нет в наличии" : "В корзину"}</button>
        </div>
      </div>
    </article>
  `;
}

function renderChips() {
  const box = qs("#chips");
  if (!box) return;
  box.innerHTML = getCategories().map(
    (c) => `<button class="chip ${state.category === c.id ? "active" : ""}" data-cat="${c.id}">${c.label}</button>`
  ).join("");
}

function renderCatalog() {
  renderChips();
  const list = filteredProducts();
  const grid = qs("#catalog-grid");
  const count = qs("#catalog-count");
  const title = qs("#catalog-title");
  const cat = getCategories().find((c) => c.id === state.category);
  if (title) title.textContent = cat && cat.id !== "all" ? cat.label : "Каталог Avangard Plus";
  if (count) count.textContent = `${list.length} товаров`;
  if (!grid) return;
  grid.innerHTML = list.length
    ? list.map(productCard).join("")
    : `<div class="empty">Ничего не найдено. Измените фильтр или добавьте товары в админке.</div>`;
}

function renderHomeProducts() {
  const grid = qs("#home-grid");
  if (!grid) return;
  const hits = state.products.filter((p) => p.badge === "Хит").slice(0, 8);
  grid.innerHTML = (hits.length ? hits : state.products.slice(0, 8)).map(productCard).join("");
}

function renderHomeCats() {
  const box = qs("#home-cats");
  if (!box) return;
  box.innerHTML = getCategories().filter((c) => c.id !== "all")
    .map((c) => {
      const n = state.products.filter((p) => p.category === c.id).length;
      const icon = CAT_ICON[c.id] || "•";
      return `<button class="cat-card" data-open-cat="${c.id}"><span class="cat-ico">${icon}</span><span>${n} моделей</span><b>${c.label}</b></button>`;
    })
    .join("");
}

function renderInstallment() {
  const grid = qs("#inst-grid");
  const count = qs("#inst-count");
  if (!grid) return;
  const list = filteredProducts().filter((p) => isHousehold(p) && p.price >= 10000);
  if (count) count.textContent = `${list.length} моделей бытовой техники`;
  const chips = qs("#inst-chips");
  if (chips) {
    chips.innerHTML = getCategories().map(
      (c) => `<button class="chip ${state.category === c.id ? "active" : ""}" data-cat="${c.id}">${CAT_ICON[c.id] || ""} ${c.label}</button>`
    ).join("");
  }
  grid.innerHTML = list.length ? list.map(productCard).join("") : `<div class="empty">Нет товаров</div>`;
}

function renderSlider() {
  const root = qs("#hero-slider");
  if (!root) return;
  const slides = (state.slides || [])
    .map((id) => state.products.find((p) => String(p.id) === String(id)))
    .filter(Boolean);
  if (!slides.length) return;
  root.innerHTML =
    slides
      .map(
        (p, i) => `
      <article class="slide ${i === 0 ? "active" : ""}" style="--slide-img:url('${p.image}')">
        <div class="container slide-inner">
          <div class="eyebrow">${p.categoryLabel} · ходовой товар</div>
          <h1>${p.name}</h1>
          <p>${p.desc}</p>
          <div class="slide-price">${formatPrice(p.price)}</div>
          <div class="hero-actions">
            <button class="btn btn-blue" data-action-slide-add="${p.id}">В корзину</button>
            <button class="btn btn-ghost" data-action-slide-open="${p.id}">Подробнее</button>
          </div>
        </div>
      </article>`
      )
      .join("") +
    `<div class="slider-nav">${slides.map((_, i) => `<button class="dot ${i === 0 ? "active" : ""}" data-slide="${i}"></button>`).join("")}</div>`;
  if (renderSlider.timer) clearInterval(renderSlider.timer);
  let idx = 0;
  const show = (n) => {
    const items = qsa(".slide", root);
    const dots = qsa(".dot", root);
    if (!items.length) return;
    idx = (n + items.length) % items.length;
    items.forEach((s, i) => s.classList.toggle("active", i === idx));
    dots.forEach((d, i) => d.classList.toggle("active", i === idx));
  };
  renderSlider.timer = setInterval(() => show(idx + 1), 5200);
  root.onclick = (e) => {
    const dot = e.target.closest("[data-slide]");
    if (dot) show(Number(dot.dataset.slide));
    const add = e.target.closest("[data-action-slide-add]");
    if (add) addToCart(Number(add.dataset.actionSlideAdd));
    const open = e.target.closest("[data-action-slide-open]");
    if (open) openProduct(Number(open.dataset.actionSlideOpen));
  };
}

function cartCount() {
  return state.cart.reduce((s, i) => s + i.qty, 0);
}
function cartGoods() {
  return state.cart.reduce((s, i) => {
    const p = state.products.find((x) => x.id === i.id);
    return s + (p ? p.price * i.qty : 0);
  }, 0);
}

function addToCart(id, qty = 1) {
  const p = state.products.find((x) => x.id === id);
  if (!p) return;
  const item = state.cart.find((x) => x.id === id);
  const next = (item ? item.qty : 0) + qty;
  if (p.stock < 1 || next > p.stock) {
    toast("На складе только " + p.stock + " шт.");
    return;
  }
  if (item) item.qty = next;
  else state.cart.push({ id, qty });
  persistCart();
  toast("Добавлено в корзину: " + p.name);
}

function setQty(id, qty) {
  const p = state.products.find((x) => x.id === id);
  if (!p) return;
  qty = Math.max(0, Math.min(p.stock, qty));
  if (qty === 0) state.cart = state.cart.filter((x) => x.id !== id);
  else {
    const item = state.cart.find((x) => x.id === id);
    if (item) item.qty = qty;
  }
  persistCart();
}

function renderCart() {
  qsa("[data-cart-count]").forEach((el) => {
    const n = cartCount();
    el.textContent = n;
    el.style.display = n ? "grid" : "none";
  });
  const box = qs("#cart-items");
  const total = qs("#cart-total");
  const checkoutBtn = qs("#checkout-btn");
  if (total) total.textContent = formatPrice(cartGoods());
  if (checkoutBtn) checkoutBtn.disabled = state.cart.length === 0;
  const instBtn = qs("#install-btn");
  const instHint = qs("#cart-inst-hint");
  const offer = canOfferInstall();
  if (instBtn) {
    instBtn.disabled = !offer || state.cart.length === 0;
    instBtn.style.display = "";
  }
  if (instHint) {
    if (!state.cart.length) instHint.textContent = "";
    else if (state.cart.some((i) => !isHousehold(state.products.find((x)=>x.id===i.id)))) {
      instHint.textContent = "Телефоны, ноутбуки и принтеры в рассрочку не входят. Считаем только бытовую технику.";
    } else if (!offer) {
      instHint.textContent = "Рассрочка от 10 000 сом на бытовую технику.";
    } else {
      const plan = planInstall(installCartTotal());
      instHint.textContent = `Рассрочка: взнос ${formatPrice(plan.down)}, далее ${plan.monthsAfter} × ${formatPrice(plan.monthly)}`;
    }
  }
  if (!box) return;
  if (!state.cart.length) {
    box.innerHTML = `<div class="empty">Корзина пуста. Добавьте товары из каталога.</div>`;
    return;
  }
  box.innerHTML = state.cart
    .map((item) => {
      const p = state.products.find((x) => x.id === item.id);
      if (!p) return "";
      return `
        <div class="cart-item">
          <img src="${(productImages(p)[0] || p.image)}" alt="${p.name}">
          <div>
            <strong>${p.name}</strong>
            <div class="muted">${formatPrice(p.price)}</div>
            <div class="qty">
              <button data-qty="${p.id}" data-d="-1">−</button>
              <span>${item.qty}</span>
              <button data-qty="${p.id}" data-d="1">+</button>
            </div>
            <button class="remove" data-remove="${p.id}">Удалить</button>
          </div>
          <div><strong>${formatPrice(p.price * item.qty)}</strong></div>
        </div>
      `;
    })
    .join("");
}

function openCart(open = true) {
  qs("#overlay").classList.toggle("open", open);
  qs("#cart-drawer").classList.toggle("open", open);
}

function openProduct(id) {
  const p = state.products.find((x) => x.id === id);
  if (!p) return;
  state.currentProduct = p;
    const imgs = productImages(p);
  state.galleryIndex = 0;
  qs("#pm-img").src = imgs[0] || p.image;
  const g = qs("#pm-gallery");
  if (g) {
    g.innerHTML = imgs.map((src, i) => `<button class="gal-dot ${i===0?"active":""}" data-gal="${i}"><img src="${src}" alt=""></button>`).join("");
  }
  qs("#pm-img").alt = p.name;
  qs("#pm-cat").textContent = p.categoryLabel || "";
  qs("#pm-title").textContent = p.name;
  qs("#pm-stars").textContent = `${stars(p.rating)} · ${p.reviews || 0} отзывов`;
  qs("#pm-desc").textContent = p.desc;
  qs("#pm-price").textContent = formatPrice(p.price);
  qs("#pm-old").textContent = p.oldPrice ? formatPrice(p.oldPrice) : "";
  qs("#pm-stock").textContent = p.stock > 0 ? `В наличии: ${p.stock} шт.` : "Нет в наличии";
  const large = typeof LARGE_CATS !== "undefined" && LARGE_CATS.includes(p.category);
  const w = qs("#pm-warranty");
  if (w) w.textContent = large ? "Гарантия на крупную технику — от 12 месяцев." : "Гарантия по условиям производителя.";
  const specs = qs("#pm-specs");
  if (specs) specs.textContent = p.specs || "";
  const box = qs("#pm-install");
  if (box) {
    if (!isHousehold(p)) {
      box.innerHTML = "";
    } else if (p.price < 10000) {
      box.innerHTML = `<div class="inst-card"><b>Рассрочка от 10 000 сом.</b><p class="muted">У этого товара показываем только наличную цену. Если в корзине наберётся бытовой техники на 10 000 сом и больше — рассрочку посчитаем на всю сумму.</p></div>`;
    } else {
      const plan = planInstall(p.price);
      box.innerHTML = `
      <div class="inst-card">
        <div class="eyebrow">Рассрочка без банка и без пени</div>
        <h3>Наличными ${formatPrice(plan.cash)}</h3>
        <p>+15% = <b>${formatPrice(plan.total)}</b></p>
        <div class="inst-grid">
          <div><span>Первоначальный взнос</span><b>${formatPrice(plan.down)}</b></div>
          <div><span>Далее ${plan.monthsAfter} мес.</span><b>${formatPrice(plan.monthly)} / мес.</b></div>
        </div>
        <p class="muted">${plan.scheme === "upto100"
          ? "До 100 000 сом: +15%, делим на 6 месяцев. Первый месяц — взнос, затем ещё 5 платежей."
          : "Свыше 100 000 сом: +15%, взнос 30%, остаток на 5 месяцев."}</p>
        <p class="muted">Оформить рассрочку можно в корзине.</p>
      </div>`;
    }
  }
  qs("#product-modal").classList.add("open");
  qs("#overlay").classList.add("open");
}

function closeModals() {
  qsa(".modal").forEach((m) => m.classList.remove("open"));
  qs("#overlay").classList.remove("open");
  qs("#cart-drawer").classList.remove("open");
}

function toast(msg) {
  const t = qs("#toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove("show"), 2400);
}

function updateHeaderAuth() {
  const user = currentUser();
  const label = qs("#auth-label");
  const adminLink = qs("#nav-admin");
  if (label) label.textContent = user ? user.name.split(" ")[0] : "Войти";
  if (adminLink) adminLink.style.display = isAdmin() ? "inline" : "none";
}

function switchAuthTab(tab) {
  qs("#auth-login-form")?.classList.toggle("hidden", tab !== "login");
  qs("#auth-register-form")?.classList.toggle("hidden", tab !== "register");
  qsa("[data-auth-tab]").forEach((b) => b.classList.toggle("active", b.dataset.authTab === tab));
}

function login(email, password) {
  const user = state.users.find((u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
  if (!user) {
    toast("Неверный email или пароль");
    return false;
  }
  state.session = { email: user.email };
  save(KEYS.session, state.session);
  updateHeaderAuth();
  toast("Здравствуйте, " + user.name + (user.bonus ? `. Бонусы: ${formatPrice(user.bonus)}` : ""));
  navigate(user.role === "admin" ? "admin" : "cabinet");
  return true;
}

function register(data) {
  if (state.users.some((u) => u.email.toLowerCase() === data.email.toLowerCase())) {
    toast("Такой email уже зарегистрирован");
    return;
  }
  const user = {
    id: uid("u"),
    name: data.name,
    email: data.email,
    phone: data.phone,
    password: data.password,
    role: "user",
    address: data.address || "",
    bonus: 1000,
    createdAt: now()
  };
  state.users.push(user);
  persistUsers();
  toast("На ваш счёт зачислено 1000 сом бонусами");
  login(data.email, data.password);
}

function logout() {
  state.session = null;
  localStorage.removeItem(KEYS.session);
  updateHeaderAuth();
  toast("Вы вышли из аккаунта");
  navigate("home");
}

function renderCabinet() {
  const user = currentUser();
  if (!user) return;
  qs("#cab-name").value = user.name;
  qs("#cab-email").value = user.email;
  qs("#cab-phone").value = user.phone || "";
  qs("#cab-address").value = user.address || "";
  qs("#cab-role").textContent = user.role === "admin" ? "Администратор" : "Покупатель";
  const bonusEl = qs("#cab-bonus");
  if (bonusEl) bonusEl.textContent = formatPrice(user.bonus || 0);

  const mine = state.orders.filter((o) => o.userEmail === user.email).slice().reverse();
  const box = qs("#cab-orders");
  if (!mine.length) {
    box.innerHTML = `<div class="empty">Заказов пока нет.</div>`;
    return;
  }
  box.innerHTML = mine
    .map(
      (o) => `
      <div class="order-card">
        <div class="order-top">
          <div>
            <b>${o.id}</b>
            <div class="muted">${o.createdAt}</div>
          </div>
          <span class="status status-${o.status}">${STATUS[o.status] || o.status}</span>
        </div>
        <div class="muted">${o.items.map((i) => `${i.name} × ${i.qty}`).join(", ")}</div>
        <div class="muted">Адрес: ${o.address || "—"}</div>
        <div class="muted">Время (Ош): ${o.createdAt}</div>
        <div class="order-foot">
          <b>${formatPrice(o.total)}</b>
          ${o.status === "pending" ? `<button class="btn btn-blue" data-pay-order="${o.id}">Оплатить</button>` : ""}
          ${["pending", "paid", "packing"].includes(o.status) ? `<button class="btn btn-outline" data-cancel-order="${o.id}">Отменить</button>` : ""}
        </div>
      </div>`
    )
    .join("");
}

function saveProfile(e) {
  e.preventDefault();
  const user = currentUser();
  if (!user) return;
  user.name = qs("#cab-name").value.trim();
  user.phone = qs("#cab-phone").value.trim();
  user.address = qs("#cab-address").value.trim();
  persistUsers();
  updateHeaderAuth();
  toast("Профиль сохранён");
}

function openCheckout(mode) {
  state.checkoutMode = mode === "installment" ? "installment" : "cash";
  if (!state.cart.length) return;
  if (!currentUser()) {
    closeModals();
    toast("Чтобы оформить заказ, войдите или зарегистрируйтесь");
    navigate("auth");
    return;
  }
  const user = currentUser();
  const form = qs("#checkout-form");
  const parts = (user.name || "").split(" ");
  if (form.lastName) form.lastName.value = parts[0] || "";
  if (form.firstName) form.firstName.value = parts[1] || "";
  if (form.middleName) form.middleName.value = parts.slice(2).join(" ");
  form.phone.value = user.phone || "";
  if (form.address) form.address.value = user.address || "";
  const bonusBox = qs("#bonus-available");
  if (bonusBox) bonusBox.textContent = formatPrice(user.bonus || 0);
  const useBonus = qs("#use-bonus");
  if (useBonus) useBonus.checked = false;
  const inst = state.checkoutMode === "installment";
  qs("#middle-wrap")?.classList.toggle("hidden", !inst);
  if (form.middleName) form.middleName.required = inst;
  qs("#bonus-row")?.classList.toggle("hidden", inst);
  qs("#pay-cash-fields")?.classList.toggle("hidden", inst);
  qs("#inst-docs")?.classList.toggle("hidden", !inst);
  qs("#cash-address")?.classList.toggle("hidden", inst);
  const title = qs("#checkout-title");
  if (title) title.textContent = inst ? "Заявка на рассрочку" : "Оформление заказа";
  renderCheckoutSummary();
  qs("#checkout-modal").classList.add("open");
  qs("#overlay").classList.add("open");
  qs("#cart-drawer").classList.remove("open");
}

function deliveryCost() {
  return 0;
}

function bonusToUse() {
  const user = currentUser();
  if (!user || state.checkoutMode === "installment") return 0;
  if (!qs("#use-bonus")?.checked) return 0;
  return Math.min(user.bonus || 0, cashBonusBase());
}

function renderCheckoutSummary() {
  const list = qs("#co-items");
  const goods = cartGoods();
  const bonus = bonusToUse();
  list.innerHTML = state.cart
    .map((item) => {
      const p = state.products.find((x) => x.id === item.id);
      return `<div class="cart-item" style="grid-template-columns:1fr auto"><div>${p.name} × ${item.qty}</div><strong>${formatPrice(p.price * item.qty)}</strong></div>`;
    })
    .join("");
  const totalEl = qs("#co-total");
  if (totalEl) totalEl.textContent = formatPrice(Math.max(0, goods - bonus));
  const note = qs("#phone-pickup-note");
  if (note) {
    const hasPhone = state.cart.some((i) => isPhone(state.products.find((x) => x.id === i.id)));
    const onlyPhone = hasPhone && state.cart.every((i) => isPhone(state.products.find((x) => x.id === i.id)));
    note.textContent = onlyPhone
      ? "Телефоны без доставки — только самовывоз на Курманжан Датка 469."
      : hasPhone
        ? "Телефоны без доставки (самовывоз). Остальную технику везём по Ошу бесплатно."
        : "Доставка по Ошу бесплатно.";
  }
  const bonusRow = qs("#bonus-row");
  if (bonusRow && state.checkoutMode !== "installment") {
    bonusRow.classList.toggle("hidden", cashBonusBase() <= 0);
  }
}

function createOrderFromCart(data, status) {
  const items = state.cart.map((item) => {
    const p = state.products.find((x) => x.id === item.id);
    return { id: p.id, name: p.name, price: p.price, qty: item.qty };
  });
  const user = currentUser();
  const requested = data.bonusUsed == null ? bonusToUse() : Number(data.bonusUsed);
  const bonus = Math.min(user.bonus || 0, cashBonusBase(), requested);
  user.bonus = Math.max(0, (user.bonus || 0) - bonus);
  persistUsers();
  const order = {
    id: uid("AP"),
    userEmail: user.email,
    items,
    goods: cartGoods(),
    shipping: 0,
    bonus,
    total: Math.max(0, cartGoods() - bonus),
    delivery: data.delivery,
    payMethod: data.pay,
    months: data.months || null,
    status,
    name: data.name,
    phone: data.phone,
    email: data.email,
    address: data.address,
    phone2: data.phone2 || "",
    regAddress: data.regAddress || "",
    docs: data.docs || null,
    confirmCode: String(1000 + Math.floor(Math.random() * 9000)),
    cashBase: state.checkoutMode === "installment" ? 0 : cashBonusBase(),
    createdAt: now(),
    paidAt: status === "paid" ? now() : null
  };
  items.forEach((i) => {
    const p = state.products.find((x) => x.id === i.id);
    if (p) p.stock = Math.max(0, p.stock - i.qty);
  });
  persistProducts();
  state.orders.push(order);
  persistOrders();
  state.cart = [];
  persistCart();
  renderCatalog();
  renderHomeProducts();
  sendOrderPack(order);
  return order;
}

function orderText(order) {
  return [
    "Заказ Avangard Plus " + order.id,
    "Время Ош: " + order.createdAt,
    "ФИО: " + (order.name || ""),
    "Телефон: " + (order.phone || "") + (order.phone2 ? " / " + order.phone2 : ""),
    "Почта аккаунта: " + (order.email || ""),
    "Адрес: " + (order.address || ""),
    order.regAddress ? "Прописка: " + order.regAddress : "",
    "Товары:",
    ...(order.items || []).map((i) => "— " + i.name + " × " + i.qty + " = " + formatPrice(i.price * i.qty)),
    "Сумма: " + formatPrice(order.total),
    "Оплата: " + (order.payMethod === "qr" ? "QR МБанк" : order.payMethod === "installment" ? "Рассрочка" : "Наличные"),
    "Напишите клиенту: Подтвердил. Код " + order.confirmCode
  ].filter(Boolean).join("\n");
}

function loadImg(src) {
  return new Promise((resolve) => {
    if (!src) return resolve(null);
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

function jpegPagesToPdf(bins, w, h) {
  const enc = new TextEncoder();
  const pageObjs = bins.map((bin, i) => {
    const pageId = 3 + i * 3;
    return { pageId, contentId: pageId + 1, imageId: pageId + 2, bin };
  });
  const total = 2 + pageObjs.length * 3;
  const objBytes = {};
  objBytes[1] = enc.encode("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");
  objBytes[2] = enc.encode("2 0 obj\n<< /Type /Pages /Count " + pageObjs.length + " /Kids [" + pageObjs.map((p) => p.pageId + " 0 R").join(" ") + "] >>\nendobj\n");
  pageObjs.forEach((p) => {
    const content = "q 595 0 0 842 0 0 cm /Im0 Do Q\n";
    objBytes[p.pageId] = enc.encode(p.pageId + " 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents " + p.contentId + " 0 R /Resources << /XObject << /Im0 " + p.imageId + " 0 R >> >> >>\nendobj\n");
    objBytes[p.contentId] = enc.encode(p.contentId + " 0 obj\n<< /Length " + content.length + " >>\nstream\n" + content + "endstream\nendobj\n");
    const raw = Uint8Array.from(p.bin, (c) => c.charCodeAt(0));
    const head = enc.encode(p.imageId + " 0 obj\n<< /Type /XObject /Subtype /Image /Width " + w + " /Height " + h + " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " + raw.length + " >>\nstream\n");
    const tail = enc.encode("\nendstream\nendobj\n");
    const merged = new Uint8Array(head.length + raw.length + tail.length);
    merged.set(head, 0);
    merged.set(raw, head.length);
    merged.set(tail, head.length + raw.length);
    objBytes[p.imageId] = merged;
  });
  const parts = [enc.encode("%PDF-1.3\n")];
  const offsets = [0];
  const sizeOf = () => parts.reduce((n, part) => n + part.length, 0);
  for (let i = 1; i <= total; i++) {
    offsets[i] = sizeOf();
    parts.push(objBytes[i]);
  }
  const xrefAt = sizeOf();
  let xref = "xref\n0 " + (total + 1) + "\n0000000000 65535 f \n";
  for (let i = 1; i <= total; i++) xref += String(offsets[i]).padStart(10, "0") + " 00000 n \n";
  xref += "trailer\n<< /Size " + (total + 1) + " /Root 1 0 R >>\nstartxref\n" + xrefAt + "\n%%EOF";
  parts.push(enc.encode(xref));
  return new Blob(parts, { type: "application/pdf" });
}

async function orderToPdfBlob(order) {
  const W = 1240;
  const H = 1754;
  const pages = [];
  let canvas;
  let ctx;
  let y = 70;
  function newPage() {
    canvas = document.createElement("canvas");
    canvas.width = W;
    canvas.height = H;
    ctx = canvas.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, W, H);
    pages.push(canvas);
    y = 80;
  }
  function line(text, size, color) {
    ctx.fillStyle = color || "#111111";
    ctx.font = (size || 28) + "px sans-serif";
    const max = W - 120;
    String(text || "").split("\n").forEach((paragraph) => {
      const words = paragraph.split(" ");
      let row = "";
      words.forEach((word) => {
        const test = row ? row + " " + word : word;
        if (ctx.measureText(test).width > max) {
          if (y > H - 80) newPage();
          ctx.fillText(row, 60, y);
          y += (size || 28) + 12;
          row = word;
        } else row = test;
      });
      if (y > H - 80) newPage();
      ctx.fillText(row, 60, y);
      y += (size || 28) + 16;
    });
  }
  async function drawShot(src, label) {
    const img = await loadImg(src);
    if (!img) return;
    line(label, 26, "#333333");
    const sc = Math.min((W - 120) / img.width, 640 / img.height, 1);
    const dw = Math.round(img.width * sc);
    const dh = Math.round(img.height * sc);
    if (y + dh > H - 60) newPage();
    ctx.drawImage(img, 60, y, dw, dh);
    y += dh + 28;
  }
  newPage();
  line("Avangard Plus", 42, "#111111");
  line("Заказ " + order.id, 36);
  line(order.createdAt, 24, "#444444");
  line("ФИО: " + (order.name || ""), 30);
  line("Телефон: " + (order.phone || "") + (order.phone2 ? " / " + order.phone2 : ""), 30);
  line("Почта: " + (order.email || ""), 28);
  line("Адрес: " + (order.address || "—"), 30);
  if (order.regAddress) line("Прописка: " + order.regAddress, 30);
  line("Оплата: " + (order.payMethod === "qr" ? "QR МБанк" : order.payMethod === "installment" ? "Рассрочка" : "Наличные"), 30);
  line("Сумма: " + formatPrice(order.total), 34);
  (order.items || []).forEach((i) => line("• " + i.name + " × " + i.qty + " — " + formatPrice(i.price * i.qty), 26));
  line("Код для клиента: " + order.confirmCode, 32, "#0b3a66");
  line("Напишите клиенту: Подтвердил. Код " + order.confirmCode, 28);
  if (order.docs) {
    await drawShot(order.docs.passportFront, "Паспорт спереди");
    await drawShot(order.docs.passportBack, "Паспорт сзади");
    await drawShot(order.docs.tunduk, "Тундук");
    await drawShot(order.docs.selfie, "Селфи");
  }
  const bins = pages.map((c) => atob(c.toDataURL("image/jpeg", 0.82).split(",")[1]));
  return jpegPagesToPdf(bins, W, H);
}

async function sendOrderPack(order) {
  if (!order) return;
  const text = orderText(order);
  const url = "https://wa.me/996557767636?text=" + encodeURIComponent(text);
  if (state.waWin && !state.waWin.closed) state.waWin.location = url;
  else window.open(url, "_blank");
  state.waWin = null;
  try {
    const blob = await orderToPdfBlob(order);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "zakaz-" + order.id + ".pdf";
    a.click();
    toast("PDF скачался. Прикрепите его в открытый чат WhatsApp.");
  } catch (err) {
    toast("Чат WhatsApp открыт. Данные заказа уже в сообщении.");
  }
}

function showReceiptAsk(order) {
  closeModals();
  state.receiptOrderId = order.id;
  const label = qs("#receipt-order");
  if (label) label.textContent = order.id;
  const input = qs("#receipt-file");
  if (input) input.value = "";
  qs("#receipt-modal")?.classList.add("open");
  qs("#overlay")?.classList.add("open");
}

function renderWaiting() {
  const box = qs("#waiting-list");
  const user = currentUser();
  if (!box || !user) return;
  const mine = state.orders.filter((o) => o.userEmail === user.email).slice().reverse();
  if (!mine.length) {
    box.innerHTML = '<div class="empty">Пока нет заказов в ожидании.</div>';
    return;
  }
  box.innerHTML = mine.map((o) => `
    <div class="order-card">
      <div class="order-top">
        <div><b>${o.id}</b><div class="muted">${o.createdAt}</div></div>
        <span class="status status-${o.status}">${o.status === "confirmed" ? "Подтверждён" : "Ожидает подтверждения"}</span>
      </div>
      <div class="muted">${o.items.map((i) => i.name + " × " + i.qty).join(", ")}</div>
      <div class="muted">${o.name} · ${o.phone}</div>
      <div class="muted">Адрес: ${o.address || "—"}</div>
      <b>${formatPrice(o.total)}</b>
      ${o.status === "confirmed"
        ? '<p class="ok-line">Магазин подтвердил заказ.</p>'
        : `<div class="confirm-row">
            <input data-code-for="${o.id}" placeholder="Код из WhatsApp" inputmode="numeric">
            <button class="btn btn-blue" type="button" data-apply-code="${o.id}">Подтвердить</button>
          </div>
          <p class="muted">Когда магазин напишет «подтвердил», введите код из этого сообщения.</p>`}
    </div>`).join("");
}

function applyConfirmCode(id) {
  const order = state.orders.find((o) => o.id === id);
  const user = currentUser();
  if (!order || !user || order.userEmail !== user.email) return;
  const input = qs('[data-code-for="' + id + '"]');
  const code = (input?.value || "").trim();
  if (code !== String(order.confirmCode)) {
    toast("Код не подошёл. Дождитесь сообщения магазина «подтвердил» с кодом.");
    return;
  }
  order.status = "confirmed";
  if (order.payMethod !== "installment") {
    const extra = Math.round((order.cashBase || 0) * 0.02);
    if (extra > 0 && !order.cashback) {
      user.bonus = (user.bonus || 0) + extra;
      order.cashback = extra;
      persistUsers();
    }
  }
  persistOrders();
  renderWaiting();
  renderCabinet();
  toast("Заказ подтверждён");
}

function sendWhatsAppCheck(order) {
  sendOrderPack(order);
}

async function submitCheckout(e) {
  e.preventDefault();
  state.waWin = window.open("about:blank", "_blank");
  const stopWa = () => { if (state.waWin && !state.waWin.closed) state.waWin.close(); state.waWin = null; };
  const form = e.target;
  const data = Object.fromEntries(new FormData(form).entries());
  const user0 = currentUser();
  data.email = user0?.email || "";
  const inst = state.checkoutMode === "installment";
  const last = (data.lastName || "").trim();
  const first = (data.firstName || "").trim();
  const middle = (data.middleName || "").trim();
  if (!last || !first || !data.phone) {
    stopWa();
    toast("Заполните фамилию, имя и телефон");
    return;
  }
  if (inst && !middle) {
    stopWa();
    toast("Для рассрочки напишите отчество по паспорту");
    return;
  }
  data.name = inst ? [last, first, middle].join(" ") : last + " " + first;
  if (!inst && !data.address) {
    stopWa();
    toast("Укажите адрес");
    return;
  }
  if (inst) {
    data.address = (data.liveAddress || "").trim();
    data.regAddress = (data.regAddress || "").trim();
    if (!data.address || !data.regAddress) {
      stopWa();
      toast("Нужен фактический адрес и адрес по прописке");
      return;
    }
    const front = qs("#doc-front")?.files?.[0];
    const back = qs("#doc-back")?.files?.[0];
    const tunduk = qs("#doc-tunduk")?.files?.[0];
    const selfie = qs("#doc-selfie")?.files?.[0];
    if (!selfie) { stopWa(); return toast("Сфотографируйте себя для сверки"); }
    if (!(front && back) && !tunduk) { stopWa(); return toast("Добавьте паспорт с двух сторон или скрин Тундук"); }
    try {
      data.docs = {
        passportFront: front ? await fileToJpeg(front, 1200) : "",
        passportBack: back ? await fileToJpeg(back, 1200) : "",
        tunduk: tunduk ? await fileToJpeg(tunduk, 1200) : "",
        selfie: await fileToJpeg(selfie, 900)
      };
    } catch {
      stopWa();
      toast("Не удалось прочитать фото");
      return;
    }
  }
  const user = currentUser();
  user.phone = data.phone;
  user.address = data.address;
  user.name = data.name;
  persistUsers();

  if (state.checkoutMode === "installment") {
    if (!canOfferInstall()) { stopWa(); toast("Рассрочка от 10 000 сом и только на бытовую технику"); return; }
    if (state.cart.some((i) => !isHousehold(state.products.find((x) => x.id === i.id)))) {
      stopWa();
      toast("Уберите телефоны/ноутбуки/принтеры — их в рассрочку не оформляем");
      return;
    }
    data.pay = "installment";
    data.bonusUsed = 0;
    const plan = planInstall(installCartTotal());
    const order = createOrderFromCart(data, "waiting");
    showSuccess(order, "Заявка на рассрочку в ожидании. Магазин проверит PDF в WhatsApp и пришлёт «подтвердил» с кодом. Взнос " + formatPrice(plan.down) + ", далее " + plan.monthsAfter + " × " + formatPrice(plan.monthly) + ".");
    return;
  }
  data.bonusUsed = bonusToUse();
  if (data.pay === "qr") {
    const order = createOrderFromCart(data, "waiting");
    showReceiptAsk(order);
    return;
  }
  const order = createOrderFromCart(data, "waiting");
  showSuccess(order, "Заказ в ожидании. Наличными платите после получения. Когда магазин напишет «подтвердил», введите код в разделе «Ожидание».");
}

function openPayment(method, existingOrder) {
  qs("#pay-amount").textContent = formatPrice(existingOrder ? existingOrder.total : state.pendingOrder.total);
  qs("#pay-card-form")?.classList.add("hidden");
  qs("#pay-sbp-box")?.classList.remove("hidden");
  qs("#pay-method-label").textContent = "Оплата по QR";
  if (existingOrder) state.pendingOrder = { existingId: existingOrder.id, total: existingOrder.total, data: null };
  qs("#payment-modal").classList.add("open");
  qs("#overlay").classList.add("open");
}

function payExisting(id) {
  const order = state.orders.find((o) => o.id === id);
  if (!order) return;
  openPayment("qr", order);
}

function cancelOrder(id) {
  const order = state.orders.find((o) => o.id === id);
  if (!order || order.status === "cancelled" || order.status === "done") return;
  order.items.forEach((i) => {
    const p = state.products.find((x) => x.id === i.id);
    if (p) p.stock += i.qty;
  });
  order.status = "cancelled";
  persistOrders();
  persistProducts();
  renderCabinet();
  renderAdmin();
  renderCatalog();
  toast("Заказ отменён, товары вернулись на склад");
}

function processPayment(e) {
  e.preventDefault();
  const methodVisible = !qs("#pay-card-form").classList.contains("hidden");
  if (methodVisible) {
    const num = qs("#card-number").value.replace(/\s/g, "");
    const exp = qs("#card-exp").value.trim();
    const cvc = qs("#card-cvc").value.trim();
    const holder = qs("#card-holder").value.trim();
    if (num.length < 16 || !exp.includes("/") || cvc.length < 3 || holder.length < 3) {
      toast("Проверьте данные карты");
      return;
    }
  }
  const btn = qs("#pay-submit");
  btn.disabled = true;
  btn.textContent = "Обработка…";
  setTimeout(() => {
    btn.disabled = false;
    btn.textContent = "Оплатить";
    let order;
    if (state.pendingOrder?.existingId) {
      order = state.orders.find((o) => o.id === state.pendingOrder.existingId);
      if (order) {
        order.status = "paid";
        order.paidAt = now();
        persistOrders();
      }
    } else {
      order = createOrderFromCart(state.pendingOrder.data, "paid");
    }
    qs("#card-number").value = "";
    qs("#card-exp").value = "";
    qs("#card-cvc").value = "";
    qs("#card-holder").value = "";
    state.pendingOrder = null;
    showSuccess(order, "Оплата прошла успешно. Это демо: деньги не списываются.");
  }, 1100);
}

function showSuccess(order, note) {
  closeModals();
  qs("#success-id").textContent = order.id;
  qs("#success-sum").textContent = formatPrice(order.total);
  qs("#success-note").textContent = note;
  qs("#success-modal").classList.add("open");
  qs("#overlay").classList.add("open");
}

function renderAdmin() {
  if (!isAdmin()) return;
  qsa("[data-admin-tab]").forEach((b) => b.classList.toggle("active", b.dataset.adminTab === state.adminTab));
  qsa(".admin-pane").forEach((p) => p.classList.toggle("hidden", p.dataset.pane !== state.adminTab));
  renderAdminProducts();
  renderAdminOrders();
  renderAdminUsers();
  renderAdminStats();
  renderAdminSlides();
  renderAdminCategories();
  renderAdminZones();
}

function renderAdminCategories() {
  const box = qs("#admin-categories");
  if (!box) return;
  const rows = getCategories().filter((c) => c.id !== "all").map((c) => `
    <div class="slide-row">
      <div class="cat-ico">${c.icon || CAT_ICON[c.id] || "•"}</div>
      <div><b>${c.label}</b><div class="muted">${c.id}</div></div>
      <button class="btn btn-danger" data-del-cat="${c.id}">Удалить</button>
    </div>`).join("");
  box.innerHTML = rows + `
    <div class="panel" style="margin-top:12px">
      <label>Новая категория</label>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
        <input id="new-cat-name" placeholder="Например: Обогреватели">
        <input id="new-cat-icon" placeholder="Иконка 🔥" style="max-width:120px">
        <button class="btn btn-blue" type="button" id="add-cat-btn">Добавить</button>
      </div>
    </div>`;
  qs("#add-cat-btn")?.addEventListener("click", () => {
    const label = qs("#new-cat-name")?.value.trim();
    if (!label) return toast("Напишите название категории");
    const id = label.toLowerCase().replace(/[^a-zа-я0-9]+/gi, "-").replace(/^-|-$/g, "") || ("cat-" + Date.now());
    if (state.categories.some((c) => c.id === id || c.label === label)) return toast("Такая категория уже есть");
    state.categories.push({ id, label, icon: qs("#new-cat-icon")?.value.trim() || "•" });
    persistCategories();
    renderAdminCategories();
    renderHomeCats();
    toast("Категория добавлена");
  });
}

function renderAdminZones() {
  const box = qs("#admin-zones");
  if (!box) return;
  box.innerHTML = state.zones.map((z, i) => `
    <div class="slide-row">
      <div style="flex:1"><b>${z.name}</b><div class="muted">${formatPrice(z.price)}</div></div>
      <button class="btn btn-outline" data-edit-zone="${i}">Изменить</button>
      <button class="btn btn-danger" data-del-zone="${i}">Удалить</button>
    </div>`).join("") + `
    <div class="panel" style="margin-top:12px">
      <label>Район и цена доставки</label>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
        <input id="zone-name" placeholder="Название района">
        <input id="zone-price" type="number" min="0" placeholder="сом" style="max-width:140px">
        <button class="btn btn-blue" type="button" id="add-zone-btn">Добавить</button>
      </div>
    </div>`;
  qs("#add-zone-btn")?.addEventListener("click", () => {
    const name = qs("#zone-name").value.trim();
    const price = Number(qs("#zone-price").value);
    if (!name || Number.isNaN(price)) return toast("Укажите район и сумму");
    state.zones.push({ id: "z" + Date.now(), name, price });
    persistZones();
    renderAdminZones();
  });
}

function renderAdminSlides() {
  const box = qs("#admin-slides");
  if (!box) return;
  const rows = state.slides
    .map((id, i) => {
      const p = state.products.find((x) => String(x.id) === String(id));
      if (!p) return "";
      return `<div class="slide-row">
        <img src="${p.image}" alt="">
        <div><b>${p.name}</b><div class="muted">${formatPrice(p.price)} · ${p.categoryLabel}</div></div>
        <div class="td-actions">
          <button class="btn btn-outline" data-slide-move="${i}" data-dir="-1">↑</button>
          <button class="btn btn-outline" data-slide-move="${i}" data-dir="1">↓</button>
          <button class="btn btn-danger" data-slide-del="${i}">Убрать</button>
        </div>
      </div>`;
    })
    .join("");
  const options = state.products
    .map((p) => `<option value="${p.id}">${p.categoryLabel}: ${p.name}</option>`)
    .join("");
  box.innerHTML = `
    <p class="muted">Слайдер на главной берёт название, цену и фото из каталога. Поменяли товар — реклама обновится сама.</p>
    ${rows || '<div class="empty">Слайдов пока нет</div>'}
    <div class="panel" style="margin-top:16px">
      <label>Добавить товар в слайд</label>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
        <select id="slide-add-select">${options}</select>
        <button class="btn btn-blue" id="slide-add-btn" type="button">Добавить в рекламу</button>
      </div>
    </div>`;
  qs("#slide-add-btn")?.addEventListener("click", () => {
    const id = qs("#slide-add-select")?.value;
    if (!id) return;
    if (state.slides.some((s) => String(s) === String(id))) return toast("Этот товар уже в слайдах");
    state.slides.push(Number(id) || id);
    persistSlides();
    renderAdminSlides();
    toast("Товар добавлен в слайд-рекламу");
  });
}

function renderAdminStats() {
  const paid = state.orders.filter((o) => ["paid", "packing", "shipped", "done", "cod"].includes(o.status));
  qs("#stat-products").textContent = state.products.length;
  qs("#stat-orders").textContent = state.orders.length;
  qs("#stat-users").textContent = state.users.length;
  qs("#stat-sum").textContent = formatPrice(paid.reduce((s, o) => s + o.total, 0));
}

function renderAdminProducts() {
  const box = qs("#admin-products");
  if (!box) return;
  box.innerHTML = `
    <table class="table">
      <thead>
        <tr><th>Товар</th><th>Категория</th><th>Цена</th><th>Склад</th><th></th></tr>
      </thead>
      <tbody>
        ${state.products
          .map(
            (p) => `<tr>
              <td><b>${p.name}</b></td>
              <td>${p.categoryLabel || p.category}</td>
              <td>${formatPrice(p.price)}</td>
              <td>${p.stock}</td>
              <td class="td-actions">
                <button class="btn btn-outline" data-edit-product="${p.id}">Изменить</button>
                <button class="btn btn-danger" data-del-product="${p.id}">Удалить</button>
              </td>
            </tr>`
          )
          .join("")}
      </tbody>
    </table>`;
}

function categoryLabel(id) {
  return getCategories().find((c) => c.id === id)?.label || id;
}

function openProductEditor(id) {
  state.editingProductId = id || null;
  const p = id ? state.products.find((x) => x.id === id) : null;
  qs("#pe-title").textContent = p ? "Редактирование товара" : "Новый товар";
  const form = qs("#product-editor-form");
  const catSel = qs("#pe-category") || form.category;
  if (catSel) {
    catSel.innerHTML = getCategories().filter((c) => c.id !== "all")
      .map((c) => `<option value="${c.id}">${c.label}</option>`)
      .join("");
  }
  form.name.value = p?.name || "";
  form.category.value = p?.category || "washers";
  form.price.value = p?.price || "";
  form.oldPrice.value = p?.oldPrice || "";
  form.stock.value = p?.stock ?? 10;
  form.badge.value = p?.badge || "";
  form.rating.value = p?.rating || 4.5;
  form.reviews.value = p?.reviews || 0;
  form.image.value = p?.image || "";
  if (form.images) form.images.value = productImages(p).join("\n");
  if (form.specs) form.specs.value = p?.specs || "";
  form.desc.value = p?.desc || "";
  qs("#pe-preview").src = productImages(p)[0] || p?.image || "";
  qs("#product-editor-modal").classList.add("open");
  qs("#overlay").classList.add("open");
}

function saveProduct(e) {
  e.preventDefault();
  const f = e.target;
  const data = Object.fromEntries(new FormData(f).entries());
  const payload = {
    name: data.name.trim(),
    category: data.category,
    categoryLabel: categoryLabel(data.category),
    price: Number(data.price),
    oldPrice: data.oldPrice ? Number(data.oldPrice) : null,
    stock: Number(data.stock),
    badge: data.badge.trim() || null,
    rating: Number(data.rating) || 0,
    reviews: Number(data.reviews) || 0,
    image: data.image.trim(),
    images: (data.images || data.image || "").split(/\n+/).map((s) => s.trim()).filter(Boolean).slice(0, 4),
    specs: (data.specs || "").trim(),
    desc: data.desc.trim()
  };
  if (!payload.images.length && payload.image) payload.images = [payload.image];
  if (!payload.image && payload.images[0]) payload.image = payload.images[0];
  if (!payload.name || !payload.price || !payload.image) {
    toast("Укажите название, цену и ссылку на фото");
    return;
  }
  if (state.editingProductId) {
    const p = state.products.find((x) => x.id === state.editingProductId);
    Object.assign(p, payload);
    toast("Товар обновлён");
  } else {
    const nextId = Math.max(0, ...state.products.map((p) => Number(p.id) || 0)) + 1;
    state.products.unshift({ id: nextId, ...payload });
    toast("Товар добавлен в каталог");
  }
  persistProducts();
  closeModals();
  renderAdmin();
  renderCatalog();
  renderHomeProducts();
  renderSlider();
}

let undoTimer = null;
function deleteProduct(id) {
  const index = state.products.findIndex((p) => String(p.id) === String(id));
  if (index < 0) return;
  const snapshot = {
    product: state.products[index],
    index,
    slides: state.slides.slice(),
    cart: state.cart.filter((i) => String(i.id) === String(id))
  };
  state.products.splice(index, 1);
  state.cart = state.cart.filter((i) => String(i.id) !== String(id));
  state.slides = state.slides.filter((s) => String(s) !== String(id));
  persistSlides();
  persistProducts();
  persistCart();
  renderAdmin();
  renderCatalog();
  renderHomeProducts();
  renderSlider();
  showUndo(snapshot);
}

function showUndo(snapshot) {
  const box = qs("#undo-toast");
  if (!box) return;
  let left = 5;
  box.innerHTML = `<b>Удалили: ${snapshot.product.name}</b><span class="undo-sec">${left}</span><button type="button" id="undo-del">Отменить</button>`;
  box.classList.add("show");
  clearInterval(undoTimer);
  undoTimer = setInterval(() => {
    left -= 1;
    const sec = box.querySelector(".undo-sec");
    if (sec) sec.textContent = String(left);
    if (left <= 0) {
      clearInterval(undoTimer);
      box.classList.remove("show");
    }
  }, 1000);
  qs("#undo-del").onclick = () => {
    clearInterval(undoTimer);
    box.classList.remove("show");
    state.products.splice(Math.min(snapshot.index, state.products.length), 0, snapshot.product);
    state.slides = snapshot.slides;
    snapshot.cart.forEach((item) => {
      if (!state.cart.some((i) => String(i.id) === String(item.id))) state.cart.push(item);
    });
    persistProducts();
    persistSlides();
    persistCart();
    renderAdmin();
    renderCatalog();
    renderHomeProducts();
    renderSlider();
  };
}

function renderAdminOrders() {
  const box = qs("#admin-orders");
  if (!box) return;
  if (!state.orders.length) {
    box.innerHTML = `<div class="empty">Заказов ещё нет.</div>`;
    return;
  }
  box.innerHTML = `
    <table class="table">
      <thead><tr><th>Заказ</th><th>Клиент</th><th>Сумма</th><th>Статус</th><th></th></tr></thead>
      <tbody>
        ${state.orders
          .slice()
          .reverse()
          .map(
            (o) => `<tr>
              <td><b>${o.id}</b><div class="muted">${o.createdAt}</div></td>
              <td>${o.name}<div class="muted">${o.email}</div></td>
              <td>${formatPrice(o.total)}<div class="muted">${o.confirmCode ? "Код клиенту: " + o.confirmCode : ""}</div></td>
              <td>
                <select data-order-status="${o.id}">
                  ${Object.entries(STATUS)
                    .map(([k, v]) => `<option value="${k}" ${o.status === k ? "selected" : ""}>${v}</option>`)
                    .join("")}
                </select>
              </td>
              <td class="td-actions">
                <button class="btn btn-outline" data-cancel-order="${o.id}">Отменить</button>
              </td>
            </tr>`
          )
          .join("")}
      </tbody>
    </table>`;
}

function renderAdminUsers() {
  const box = qs("#admin-users");
  if (!box) return;
  box.innerHTML = `
    <table class="table">
      <thead><tr><th>Имя</th><th>Email</th><th>Телефон</th><th>Роль</th></tr></thead>
      <tbody>
        ${state.users
          .map(
            (u) => `<tr>
              <td>${u.name}</td>
              <td>${u.email}</td>
              <td>${u.phone || "—"}</td>
              <td>
                <select data-user-role="${u.email}">
                  <option value="user" ${u.role === "user" ? "selected" : ""}>Покупатель</option>
                  <option value="admin" ${u.role === "admin" ? "selected" : ""}>Админ</option>
                </select>
              </td>
            </tr>`
          )
          .join("")}
      </tbody>
    </table>`;
}

function resetCatalog() {
  if (!confirm("Вернуть стартовый набор товаров? Ваши добавленные позиции пропадут.")) return;
  state.products = structuredClone(PRODUCTS);
  persistProducts();
  renderAdmin();
  renderCatalog();
  renderHomeProducts();
  toast("Каталог сброшен к исходному");
}

function bind() {
  qsa("[data-page]").forEach((el) => {
    el.addEventListener("click", (ev) => {
      ev.preventDefault();
      navigate(el.dataset.page);
    });
  });

  qs("#menu-toggle")?.addEventListener("click", () => qs(".nav").classList.toggle("open"));
  qs("#cart-open")?.addEventListener("click", () => openCart(true));
  qs("#overlay")?.addEventListener("click", closeModals);
  qsa("[data-close]").forEach((b) => b.addEventListener("click", closeModals));

  qs("#search")?.addEventListener("input", (e) => {
    state.query = e.target.value;
    renderSuggest(e.target.value);
    if (!qs("#page-catalog").classList.contains("active")) navigate("catalog");
    else renderCatalog();
  });
  qs("#search")?.addEventListener("focus", (e) => renderSuggest(e.target.value));
  qs("#logo-burger")?.addEventListener("click", (e) => {
    e.preventDefault();
    qs("#burger-menu")?.classList.toggle("open");
  });
  document.addEventListener("click", (e) => {
    if (!e.target.closest(".logo-wrap")) qs("#burger-menu")?.classList.remove("open");
    if (!e.target.closest(".search-wrap")) qs("#suggest")?.classList.remove("open");
  });
  qs("#to-top")?.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
  qs("#go-home")?.addEventListener("click", () => navigate("home"));
  qs("#go-back")?.addEventListener("click", () => {
    const prev = state.history.pop() || "home";
    navigate(prev, true);
  });
  window.addEventListener("scroll", () => {
    qs("#to-top")?.classList.toggle("show", window.scrollY > 420);
  });
  qs("#pay-select")?.addEventListener("change", (e) => {
    qs("#checkout-qr")?.classList.toggle("hidden", e.target.value !== "qr");
  });

  document.addEventListener("click", (e) => {
    const chip = e.target.closest("#chips [data-cat], #inst-chips [data-cat]");
    if (chip) {
      state.category = chip.dataset.cat;
      if (state.installmentMode) renderInstallment();
      else renderCatalog();
    }
  });

  qs("#sort")?.addEventListener("change", (e) => {
    state.sort = e.target.value;
    renderCatalog();
  });

  document.addEventListener("click", (e) => {
    const cardGal = e.target.closest("[data-card-gal]");
    if (cardGal) {
      const cardEl = cardGal.closest(".card");
      const prod = state.products.find((x) => String(x.id) === String(cardEl?.dataset.id));
      const imgs = productImages(prod).slice(0, 4);
      if (!prod || imgs.length < 2) return;
      let i = Number(cardEl.dataset.gi || 0) + Number(cardGal.dataset.cardGal);
      if (i < 0) i = imgs.length - 1;
      if (i >= imgs.length) i = 0;
      cardEl.dataset.gi = String(i);
      const img = cardEl.querySelector(".card-photo");
      if (img) img.src = imgs[i];
      const c = cardEl.querySelector(".gal-count");
      if (c) c.textContent = (i + 1) + "/" + imgs.length;
      return;
    }
    if (e.target.closest(".card-photo")) {
      const photoCard = e.target.closest(".card");
      if (photoCard) openProduct(Number(photoCard.dataset.id) || photoCard.dataset.id);
      return;
    }
    const card = e.target.closest(".card");
    const action = e.target.closest("[data-action]");
    if (card && action && action.dataset.action === "add") addToCart(Number(card.dataset.id) || card.dataset.id);
    const qtyBtn = e.target.closest("[data-qty]");
    if (qtyBtn) {
      const id = Number(qtyBtn.dataset.qty);
      const item = state.cart.find((x) => x.id === id);
      setQty(id, (item?.qty || 0) + Number(qtyBtn.dataset.d));
    }
    const rm = e.target.closest("[data-remove]");
    if (rm) setQty(Number(rm.dataset.remove), 0);

    const tab = e.target.closest("[data-auth-tab]");
    if (tab) switchAuthTab(tab.dataset.authTab);

    const adminTab = e.target.closest("[data-admin-tab]");
    if (adminTab) {
      state.adminTab = adminTab.dataset.adminTab;
      renderAdmin();
    }
    const editP = e.target.closest("[data-edit-product]");
    if (editP) openProductEditor(Number(editP.dataset.editProduct) || editP.dataset.editProduct);
    const delP = e.target.closest("[data-del-product]");
    if (delP) deleteProduct(Number(delP.dataset.delProduct) || delP.dataset.delProduct);
    const payO = e.target.closest("[data-pay-order]");
    if (payO) payExisting(payO.dataset.payOrder);
    const canO = e.target.closest("[data-cancel-order]");
    if (canO) cancelOrder(canO.dataset.cancelOrder);
    const oc = e.target.closest("[data-open-cat]");
    if (oc) openCategory(oc.dataset.openCat);
    const sug = e.target.closest("[data-sug-type]");
    if (sug) {
      if (sug.dataset.sugType === "cat") openCategory(sug.dataset.sugId);
      else openProduct(Number(sug.dataset.sugId) || sug.dataset.sugId);
      qs("#suggest")?.classList.remove("open");
    }
    const sm = e.target.closest("[data-slide-move]");
    if (sm) {
      const i = Number(sm.dataset.slideMove);
      const dir = Number(sm.dataset.dir);
      const j = i + dir;
      if (j < 0 || j >= state.slides.length) return;
      const arr = state.slides;
      [arr[i], arr[j]] = [arr[j], arr[i]];
      persistSlides();
      renderAdminSlides();
    }
    const sd = e.target.closest("[data-slide-del]");
    if (sd) {
      state.slides.splice(Number(sd.dataset.slideDel), 1);
      persistSlides();
      renderAdminSlides();
    }
    const dc = e.target.closest("[data-del-cat]");
    if (dc) {
      state.categories = getCategories().filter((c) => c.id !== dc.dataset.delCat);
      persistCategories();
      renderAdminCategories();
      renderHomeCats();
    }
    const codeBtn = e.target.closest("[data-apply-code]");
    if (codeBtn) applyConfirmCode(codeBtn.dataset.applyCode);
    const gal = e.target.closest("[data-gal]");
    if (gal) {
      state.galleryIndex = Number(gal.dataset.gal);
      const imgs = productImages(state.currentProduct);
      if (qs("#pm-img") && imgs[state.galleryIndex]) qs("#pm-img").src = imgs[state.galleryIndex];
      qsa("#pm-gallery [data-gal]").forEach((b) => b.classList.toggle("active", b.dataset.gal === gal.dataset.gal));
    }
    const ez = e.target.closest("[data-edit-zone]");
    if (ez) {
      const z = state.zones[Number(ez.dataset.editZone)];
      if (!z) return;
      const name = prompt("Название района", z.name);
      if (!name) return;
      const price = prompt("Цена, сом", String(z.price));
      if (price == null) return;
      z.name = name.trim();
      z.price = Number(price) || 0;
      persistZones();
      renderAdminZones();
    }
    const dz = e.target.closest("[data-del-zone]");
    if (dz) {
      state.zones.splice(Number(dz.dataset.delZone), 1);
      persistZones();
      renderAdminZones();
    }
    const info = e.target.closest("[data-info]");
    if (info) openInfo(info.dataset.info);
    if (e.target.closest("#terms-accept")) {
      closeModals();
      openCheckout("installment");
    }
  });

  document.addEventListener("change", (e) => {
    const st = e.target.closest("[data-order-status]");
    if (st) {
      const order = state.orders.find((o) => o.id === st.dataset.orderStatus);
      if (order) {
        order.status = st.value;
        persistOrders();
        toast("Статус заказа обновлён");
        renderAdminStats();
      }
    }
    const role = e.target.closest("[data-user-role]");
    if (role) {
      const user = state.users.find((u) => u.email === role.dataset.userRole);
      if (user) {
        user.role = role.value;
        persistUsers();
        updateHeaderAuth();
        toast("Роль пользователя изменена");
      }
    }
  });

  qs("#pm-add")?.addEventListener("click", () => {
    if (state.currentProduct) addToCart(state.currentProduct.id);
  });
  qs("#checkout-btn")?.addEventListener("click", () => openCheckout("cash"));
  qs("#install-btn")?.addEventListener("click", () => {
    if (!canOfferInstall()) return toast("Рассрочка от 10 000 сом, только бытовая техника");
    if (state.cart.some((i) => !isHousehold(state.products.find((x) => x.id === i.id)))) {
      return toast("Уберите телефоны, ноутбуки и принтеры из корзины");
    }
    qs("#cart-drawer").classList.remove("open");
    qs("#terms-modal").classList.add("open");
    qs("#overlay").classList.add("open");
  });
  qs("#checkout-form")?.addEventListener("submit", submitCheckout);
  qs("#checkout-form")?.delivery?.addEventListener("change", renderCheckoutSummary);
  qs("#use-bonus")?.addEventListener("change", renderCheckoutSummary);
  qs("#pay-select")?.addEventListener("change", (e) => {
    qs("#checkout-qr")?.classList.toggle("hidden", e.target.value !== "qr");
  });
  qs("#contact-form")?.addEventListener("submit", (e) => {
    e.preventDefault();
    e.target.reset();
    toast("Сообщение отправлено.");
  });
  qs("#login-form")?.addEventListener("submit", (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    login(fd.get("email"), fd.get("password"));
  });
  qs("#register-form")?.addEventListener("submit", (e) => {
    e.preventDefault();
    const fd = Object.fromEntries(new FormData(e.target).entries());
    if (fd.password.length < 4) return toast("Пароль слишком короткий");
    register(fd);
  });
  qs("#profile-form")?.addEventListener("submit", saveProfile);
  qs("#logout-btn")?.addEventListener("click", logout);
  qs("#add-product-btn")?.addEventListener("click", () => openProductEditor(null));
  qs("#product-editor-form")?.addEventListener("submit", saveProduct);
  qs("#reset-catalog-btn")?.addEventListener("click", resetCatalog);
  qs("#pay-form")?.addEventListener("submit", processPayment);
  qs("#send-receipt")?.addEventListener("click", async () => {
    const file = qs("#receipt-file")?.files?.[0];
    const order = state.orders.find((o) => o.id === state.receiptOrderId);
    if (!file) return toast("Выберите фото чека");
    const text = "Чек оплаты по заказу " + (order?.id || "") + ". Avangard Plus.";
    const url = "https://wa.me/996557767636?text=" + encodeURIComponent(text);
    window.open(url, "_blank");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(file);
    a.download = "chek-" + (order?.id || "oplata") + ".jpg";
    a.click();
    toast("Откройте чат WhatsApp и прикрепите скачанный чек.");
  });
  qs("#go-waiting")?.addEventListener("click", () => {
    closeModals();
    navigate("waiting");
  });

  document.querySelectorAll(".pe-slot").forEach((input) => {
    input.addEventListener("change", async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      let url;
      try { url = await fileToJpeg(file, 1000); } catch { return toast("Фото не прочиталось"); }
      const form = qs("#product-editor-form");
      const lines = (form.images.value || "").split(/\n+/).map((s) => s.trim()).filter(Boolean);
      const slot = Number(input.dataset.slot);
      lines[slot] = url;
      const next = lines.filter(Boolean).slice(0, 4);
      form.images.value = next.join("\n");
      form.image.value = next[0] || "";
      qs("#pe-preview").src = next[0] || "";
    });
  });
  qs("#product-editor-form")?.image?.addEventListener("input", (e) => {
    qs("#pe-preview").src = e.target.value;
  });

  qs("#card-number")?.addEventListener("input", (e) => {
    const digits = e.target.value.replace(/\D/g, "").slice(0, 16);
    e.target.value = digits.replace(/(\d{4})(?=\d)/g, "$1 ");
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeModals();
  });
}


function openInfo(kind) {
  const title = qs("#info-title");
  const body = qs("#info-body");
  if (!title || !body) return;
  if (kind === "delivery") {
    title.textContent = "Доставка";
    const zones = state.zones.map((z, i) => `<li>${i + 1}. ${z.name} — ${formatPrice(z.price)}</li>`).join("");
    body.innerHTML = `<p>Доставка по городу Ош бесплатно, только до подъезда.</p>
      <p>Если есть лифт и товар нужно поднять на этаж — помогите доставщику донести его до лифта, дальше он донесёт до двери.</p>
      <p>Если лифта нет: <b>200 сом за каждый товар и за каждый этаж</b>. Одна стиральная машина на 4-й этаж — 800 сом.</p>
      <p><b>Доставка за городом</b></p><ol class="zone-list">${zones}</ol>`;
  } else if (kind === "cash") {
    title.textContent = "Наличные после получения";
    body.innerHTML = `<p>Если у вас наличные и заказ не в рассрочку, можно оплатить всю сумму товара наличными после получения.</p>`;
  } else {
    title.textContent = "Гарантия";
    body.innerHTML = `<p>Гарантия даётся только на ремонт товара.</p>
      <p>Если товар с заводским браком — меняем его на такой же новый.</p>
      <p>Холодильники — 36 месяцев. Стиральные машины — 32 месяца.</p>
      <p>На товары LG гарантия 12 месяцев, отдельно сервис мотора на 10 лет. Гарантию и сервис на LG даёт компания LG, не магазин.</p>`;
  }
  qs("#info-modal").classList.add("open");
  qs("#overlay").classList.add("open");
}

document.addEventListener("DOMContentLoaded", () => {
  initStore();
  bind();
  updateHeaderAuth();
  renderHomeProducts();
  renderHomeCats();
  renderSlider();
  renderCatalog();
  renderCart();
});
