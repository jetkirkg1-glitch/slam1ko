import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <iframe
      title="Avangard Plus"
      src="/avangard/index.html"
      style={{ position: "fixed", inset: 0, width: "100%", height: "100%", border: 0, background: "#070712" }}
    />
  );
}
